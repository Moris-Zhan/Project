/** Automatically generated file. DO NOT MODIFY */
package tw.edu.nkfust.eHat;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}